from . import myguitargui

def run():
    myguitargui.startTuner()
